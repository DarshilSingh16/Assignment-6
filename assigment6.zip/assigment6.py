# calculator 
import tkinter as tk

# Function to update expression
def press(key):
    entry_text.set(entry_text.get() + str(key))

# Function to evaluate expression
def equal():
    try:
        result = str(eval(entry_text.get()))
        entry_text.set(result)
    except:
        entry_text.set("Error")

# Function to clear entry
def clear():
    entry_text.set("")

# Create main window
root = tk.Tk()
root.title("Calculator")
root.geometry("400x400")
root.resizable(False, False)

# Entry field
entry_text = tk.StringVar()
entry = tk.Entry(root, textvariable=entry_text, font=("Arial", 20), bd=10, relief=tk.RIDGE, justify="right")
entry.pack(fill="x", padx=10, pady=10)

# Buttons frame
frame = tk.Frame(root)
frame.pack()

# Button layout
buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    '0', '.', '=', '+'
]

row = 0
col = 0

for btn in buttons:
    if btn == '=':
        action = equal
    else:
        action = lambda x=btn: press(x)

    tk.Button(frame, text=btn, width=6, height=2, font=("Arial", 14),
              command=action).grid(row=row, column=col, padx=5, pady=5)

    col += 1
    if col == 4:
        col = 0
        row += 1

# Clear button
tk.Button(root, text="CLEAR", width=25, height=2, font=("Arial", 12),
          command=clear).pack(pady=10)

# Run application
root.mainloop()
